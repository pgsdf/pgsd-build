# Axiom Development Roadmap

This roadmap outlines the path from current implementation to production-ready system manager for PGSD.

## Current Status

### ✅ Phase 1: Core Implementation (COMPLETE)
- [x] Manifest and dependency YAML parsing
- [x] Profile management (create, list, show, load, save)
- [x] SQLite-backed index database
- [x] Dependency resolution with version constraints
- [x] ZFS dataset realization
- [x] Store operations (list, verify, garbage collection)
- [x] Complete CLI with all commands
- [x] ZFS operations (snapshot, clone, mountpoint)

**Status**: ~1,500 lines of Go code, builds successfully, all features functional

---

## Phase 2: Package Building & Tooling (HIGH PRIORITY)

### 2.1 Package Builder Tool
**Goal**: Create packages from FreeBSD pkg and place them in Axiom store

**Tasks**:
- [ ] Create `axiom-build` CLI tool
- [ ] Command: `axiom-build pkg <freebsd-pkg-name>` 
- [ ] Fetch FreeBSD package from official repos
- [ ] Extract package contents to temporary location
- [ ] Generate `manifest.yaml` from pkg metadata
- [ ] Generate `deps.yaml` from pkg dependencies
- [ ] Create ZFS dataset in store
- [ ] Copy package files to dataset
- [ ] Run `axiom index -rebuild`

**Deliverables**:
- `cmd/axiom-build/` - New CLI tool
- Support for pkg-to-axiom conversion
- Automatic manifest generation

**Estimated Effort**: 3-5 days

---

### 2.2 Manifest Generator
**Goal**: Automate manifest.yaml and deps.yaml creation

**Tasks**:
- [ ] Create `axiom manifest generate` command
- [ ] Parse FreeBSD pkg metadata format
- [ ] Map pkg dependencies to Axiom requirements
- [ ] Handle version constraints correctly
- [ ] Generate provides declarations
- [ ] Support custom overrides via config

**Deliverables**:
- Manifest generation from pkg database
- Dependency mapping logic
- Template system for custom packages

**Estimated Effort**: 2-3 days

---

### 2.3 Package Validation
**Goal**: Ensure packages are correctly formatted before adding to store

**Tasks**:
- [ ] Add `axiom package validate <path>` command
- [ ] Validate manifest.yaml schema
- [ ] Validate deps.yaml schema
- [ ] Check for required files (root/, manifest.yaml, deps.yaml)
- [ ] Verify no conflicts with existing packages
- [ ] Pre-flight checks before store insertion

**Deliverables**:
- Package validation command
- Clear error messages for issues
- Integration with package builder

**Estimated Effort**: 2 days

---

## Phase 3: Integration with pgsd-build (HIGH PRIORITY)

### 3.1 Update Image Build Pipeline
**Goal**: Replace direct pkg installation with Axiom profiles

**Tasks**:
- [ ] Modify `internal/image/image.go` in pgsd-build
- [ ] Add Axiom profile field to image recipes
- [ ] Import axiom-integration package
- [ ] Replace package installation logic with axiom-integration calls
- [ ] Handle profile resolution errors
- [ ] Update image build workflow

**Example Change**:
```go
// OLD: Install packages directly
for _, pkg := range image.Packages {
    installPackage(pkg)
}

// NEW: Use Axiom profile
runner := axiomrunner.NewRunner()
dataset, err := runner.BuildRootForProfile(image.AxiomProfile)
// Snapshot dataset to root.zfs.xz
```

**Deliverables**:
- Updated pgsd-build image builder
- Migration from pkg lists to Axiom profiles
- Updated image recipe format

**Estimated Effort**: 3-4 days

---

### 3.2 Create PGSD Profiles
**Goal**: Define system profiles for PGSD distributions

**Tasks**:
- [ ] Create `pgsd-base` profile (minimal system)
- [ ] Create `pgsd-desktop` profile (Arcan/Durden desktop)
- [ ] Create `pgsd-server` profile (headless server)
- [ ] Create `pgsd-dev` profile (development tools)
- [ ] Document profile structure
- [ ] Add profiles to version control

**Profile Examples**:
```yaml
# profiles/pgsd-base/profile.yaml
schema_version: 1
profile:
  name: pgsd-base
  description: Minimal PGSD base system
  abi: PGSD:1:x86_64
packages:
  - freebsd-kernel
  - freebsd-base
  - zfs-tools
  - openssh
```

**Deliverables**:
- Standard PGSD profiles
- Profile documentation
- Example profiles for reference

**Estimated Effort**: 2-3 days

---

### 3.3 Populate Package Store
**Goal**: Build initial package set from FreeBSD

**Tasks**:
- [ ] List required FreeBSD packages for PGSD
- [ ] Build Axiom packages from FreeBSD pkg
- [ ] Populate store with base system packages
- [ ] Populate store with desktop packages
- [ ] Populate store with development tools
- [ ] Run index rebuild
- [ ] Verify all packages

**Package Sets**:
- Base: kernel, userland, shells, core utilities (~50 packages)
- Desktop: Arcan, Durden, X11 libs, fonts (~100 packages)
- Network: OpenSSH, WiFi tools, network utilities (~30 packages)
- Development: compilers, build tools, debuggers (~80 packages)

**Deliverables**:
- Populated Axiom store with 250+ packages
- Indexed package database
- Documentation of package list

**Estimated Effort**: 5-7 days (mostly automation + testing)

---

## Phase 4: Testing & Quality Assurance

### 4.1 Unit Tests
**Goal**: Comprehensive test coverage for all packages

**Tasks**:
- [ ] Add tests for `internal/manifest/`
- [ ] Add tests for `internal/profile/`
- [ ] Add tests for `internal/index/`
- [ ] Add tests for `internal/resolver/`
- [ ] Add tests for `internal/realise/`
- [ ] Add tests for `internal/store/`
- [ ] Mock ZFS operations for testing
- [ ] Achieve >80% code coverage

**Deliverables**:
- Test files for all packages
- Test utilities and mocks
- CI integration for tests

**Estimated Effort**: 4-5 days

---

### 4.2 Integration Tests
**Goal**: End-to-end testing of complete workflows

**Tasks**:
- [ ] Test: init → populate → index → resolve → realise
- [ ] Test: Profile creation and resolution
- [ ] Test: Package store garbage collection
- [ ] Test: Index rebuild and verification
- [ ] Test: Integration with pgsd-build
- [ ] Create test fixtures and sample data

**Test Scenarios**:
1. Create profile → resolve deps → materialize system
2. Upgrade package → re-resolve → verify lock file changes
3. Add conflicting package → verify error handling
4. Garbage collect → verify only unused packages removed

**Deliverables**:
- Integration test suite
- Test data and fixtures
- Automated test execution

**Estimated Effort**: 3-4 days

---

### 4.3 Performance Testing
**Goal**: Ensure Axiom performs well at scale

**Tasks**:
- [ ] Benchmark resolver with large dependency graphs
- [ ] Benchmark index queries with 1000+ packages
- [ ] Test realization with 100+ package profiles
- [ ] Optimize slow operations
- [ ] Profile memory usage
- [ ] Document performance characteristics

**Deliverables**:
- Performance benchmarks
- Optimization recommendations
- Resource usage documentation

**Estimated Effort**: 2-3 days

---

## Phase 5: Documentation & User Experience

### 5.1 User Documentation
**Goal**: Complete guides for using Axiom

**Tasks**:
- [ ] Getting Started guide
- [ ] Profile creation tutorial
- [ ] Package building guide
- [ ] Troubleshooting guide
- [ ] FAQ document
- [ ] Man pages for all commands
- [ ] Architecture diagrams

**Deliverables**:
- `docs/getting-started.md`
- `docs/profiles.md`
- `docs/packages.md`
- `docs/troubleshooting.md`
- Updated man pages

**Estimated Effort**: 3-4 days

---

### 5.2 Developer Documentation
**Goal**: Enable contributors to extend Axiom

**Tasks**:
- [ ] Code architecture documentation
- [ ] API documentation
- [ ] Contribution guidelines
- [ ] Coding standards
- [ ] Release process documentation
- [ ] Module interaction diagrams

**Deliverables**:
- `CONTRIBUTING.md`
- `ARCHITECTURE.md` (enhanced)
- `DEVELOPMENT.md`
- API reference documentation

**Estimated Effort**: 2-3 days

---

### 5.3 CLI Improvements
**Goal**: Better user experience and error messages

**Tasks**:
- [ ] Add progress bars for long operations
- [ ] Improve error messages with actionable suggestions
- [ ] Add colored output for better readability
- [ ] Add `--verbose` and `--quiet` flags
- [ ] Add bash/zsh completion scripts
- [ ] Improve help text formatting

**Deliverables**:
- Enhanced CLI output
- Better error handling
- Shell completion support

**Estimated Effort**: 2-3 days

---

## Phase 6: Production Readiness

### 6.1 CI/CD Pipeline
**Goal**: Automated testing and releases

**Tasks**:
- [ ] Set up GitHub Actions workflow
- [ ] Automated testing on commits
- [ ] Automated builds for releases
- [ ] Cross-platform testing (FreeBSD, Linux for dev)
- [ ] Automated release packaging
- [ ] Version tagging automation

**Deliverables**:
- `.github/workflows/test.yml`
- `.github/workflows/release.yml`
- Automated test execution
- Release artifacts

**Estimated Effort**: 2-3 days

---

### 6.2 Error Recovery & Resilience
**Goal**: Handle failures gracefully

**Tasks**:
- [ ] Add transaction rollback for failed operations
- [ ] Implement retry logic for transient failures
- [ ] Add recovery commands for corrupted state
- [ ] Implement backup/restore for profiles
- [ ] Add health check command
- [ ] Logging improvements

**Deliverables**:
- Robust error handling
- Recovery utilities
- Health monitoring

**Estimated Effort**: 3-4 days

---

### 6.3 Security & Validation
**Goal**: Ensure system security and integrity

**Tasks**:
- [ ] Add package signature verification
- [ ] Implement checksum validation
- [ ] Add provenance tracking
- [ ] Security audit of ZFS operations
- [ ] Input validation hardening
- [ ] Dependency security scanning

**Deliverables**:
- Security documentation
- Signature verification
- Audit logs

**Estimated Effort**: 4-5 days

---

## Phase 7: Advanced Features

### 7.1 Environment Management
**Goal**: Support for multiple active environments

**Tasks**:
- [ ] Implement `axiom env create` command
- [ ] Clone profiles to environments
- [ ] Activate/deactivate environments
- [ ] List running environments
- [ ] Environment switching support
- [ ] Integration with boot environments

**Deliverables**:
- Environment management commands
- ZFS clone-based environments
- Boot environment integration

**Estimated Effort**: 3-5 days

---

### 7.2 Upgrade & Migration Tools
**Goal**: Seamless system upgrades

**Tasks**:
- [ ] Add `axiom upgrade` command
- [ ] Profile version migrations
- [ ] Dependency resolution for upgrades
- [ ] Rollback support
- [ ] Upgrade testing in separate environment
- [ ] Automatic backup before upgrade

**Deliverables**:
- Upgrade workflow
- Migration utilities
- Rollback mechanism

**Estimated Effort**: 4-5 days

---

### 7.3 Remote Package Repositories
**Goal**: Support for remote package sources

**Tasks**:
- [ ] Add repository configuration
- [ ] Implement package fetching from remote
- [ ] Package signature verification
- [ ] Repository mirroring support
- [ ] Local cache management
- [ ] Repository priority system

**Deliverables**:
- Remote repository support
- Repository configuration
- Package download system

**Estimated Effort**: 5-7 days

---

### 7.4 Build Provenance & Reproducibility
**Goal**: Track package build information

**Tasks**:
- [ ] Implement `provenance.yaml` generation
- [ ] Record build environment details
- [ ] Track source versions
- [ ] Generate reproducibility metadata
- [ ] Verification of reproducible builds
- [ ] Build audit trail

**Deliverables**:
- Provenance tracking
- Build metadata
- Reproducibility verification

**Estimated Effort**: 3-4 days

---

## Phase 8: Ecosystem Integration

### 8.1 pgsd-build Full Integration
**Goal**: Complete migration from pkg to Axiom

**Tasks**:
- [ ] Remove legacy pkg-based code from pgsd-build
- [ ] Update all image recipes to use Axiom profiles
- [ ] Update bootenv variants to use Axiom
- [ ] Update installer to understand Axiom
- [ ] End-to-end testing of full pipeline
- [ ] Documentation updates

**Deliverables**:
- Fully Axiom-based pgsd-build
- All recipes migrated
- Updated documentation

**Estimated Effort**: 5-7 days

---

### 8.2 Package Repository Setup
**Goal**: Official PGSD package repository

**Tasks**:
- [ ] Set up package build infrastructure
- [ ] Create automated package building
- [ ] Set up package hosting (CDN/mirror)
- [ ] Implement package signing
- [ ] Create package submission workflow
- [ ] Documentation for package maintainers

**Deliverables**:
- Official PGSD package repository
- Package build automation
- Package submission process

**Estimated Effort**: 7-10 days

---

### 8.3 Migration Tooling
**Goal**: Migrate existing PGSD systems to Axiom

**Tasks**:
- [ ] Create `axiom migrate` command
- [ ] Detect installed packages on legacy system
- [ ] Generate profile from current system
- [ ] Migration testing framework
- [ ] Rollback support
- [ ] Migration documentation

**Deliverables**:
- Migration utilities
- System analysis tools
- Migration guides

**Estimated Effort**: 4-5 days

---

## Timeline Summary

### Sprint 1 (Weeks 1-2): Foundation
- Phase 2: Package Building & Tooling
- Phase 3.1-3.2: Basic pgsd-build Integration

**Deliverables**: Can build packages and create profiles

---

### Sprint 2 (Weeks 3-4): Integration
- Phase 3.3: Populate Package Store
- Phase 4.1: Unit Tests
- Phase 5.1: User Documentation

**Deliverables**: Populated store, tested code, documented

---

### Sprint 3 (Weeks 5-6): Production Prep
- Phase 4.2: Integration Tests
- Phase 6.1-6.2: CI/CD & Error Recovery
- Phase 5.2-5.3: Dev Docs & CLI Improvements

**Deliverables**: Production-ready with tests and docs

---

### Sprint 4 (Weeks 7-8): Advanced Features
- Phase 7.1-7.2: Environments & Upgrades
- Phase 6.3: Security
- Phase 8.1: Full pgsd-build Integration

**Deliverables**: Feature-complete with security

---

### Sprint 5+ (Weeks 9+): Ecosystem
- Phase 7.3-7.4: Remote Repos & Provenance
- Phase 8.2-8.3: Repository & Migration
- Polish and refinement

**Deliverables**: Complete PGSD ecosystem

---

## Critical Path

**Must Have for Basic Functionality**:
1. ✅ Core implementation (DONE)
2. Package builder tool (Phase 2.1)
3. Populate package store (Phase 3.3)
4. Basic pgsd-build integration (Phase 3.1)
5. Unit tests (Phase 4.1)

**Must Have for Production**:
6. Integration tests (Phase 4.2)
7. User documentation (Phase 5.1)
8. CI/CD pipeline (Phase 6.1)
9. Error recovery (Phase 6.2)

**Nice to Have**:
- Environment management (Phase 7.1)
- Remote repositories (Phase 7.3)
- Migration tooling (Phase 8.3)

---

## Dependencies

```
Phase 1 (Core) ✅
    ↓
Phase 2 (Package Building) → Required for Phase 3.3
    ↓
Phase 3 (Integration) → Required for end-to-end workflow
    ↓
Phase 4 (Testing) → Can start after Phase 2
    ↓
Phase 5 (Documentation) → Can run parallel to Phase 4
    ↓
Phase 6 (Production) → Requires Phases 4 & 5
    ↓
Phase 7 (Advanced) → Builds on Phase 6
    ↓
Phase 8 (Ecosystem) → Final integration
```

---

## Metrics for Success

- [ ] Can build a package from FreeBSD pkg in <5 minutes
- [ ] Can resolve a 100-package profile in <10 seconds
- [ ] Can materialize a system in <2 minutes
- [ ] Can build a complete pgsd-desktop ISO using Axiom
- [ ] >80% code coverage with tests
- [ ] Zero critical bugs in production
- [ ] Complete documentation for all features
- [ ] Successful migration of at least one existing PGSD system

---

## Notes

- Phases 2-3 are **critical path** - needed for basic functionality
- Phase 4 can start alongside Phase 2-3 development
- Phase 5 documentation should be written as features are implemented
- Phases 7-8 are enhancement/polish and can be deferred
- Security (Phase 6.3) should be reviewed throughout development

---

## Current Blockers

1. **No package builder** - Can't populate store without manual work
2. **No pgsd-build integration** - Can't test end-to-end workflow
3. **No tests** - Risk of regressions
4. **No populated store** - Can't test real-world scenarios

**Recommended Next Steps**:
1. Start Phase 2.1 (Package Builder Tool) immediately
2. Create sample packages manually to test workflows
3. Begin Phase 3.2 (Create PGSD Profiles) in parallel
4. Write unit tests as new features are added

---

Last Updated: 2025-11-28
